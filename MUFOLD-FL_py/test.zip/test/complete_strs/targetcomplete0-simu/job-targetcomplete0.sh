#!/bin/tcsh 


set bindir = /Applications/LocalApps/NAMD_2.9_MacOSX-x86_64-multicore/

set name = minimize-fixedrest-targetcomplete0
$bindir/namd2 +p4 ${name}.conf >& minimize-targetcomplete0.out
vmd -dispdev text -e /Users/jiong/jiong/projects/5_MUFOLD-FL/MUFOLD-FL_py_skMDS/FLMD//script/coor2pdb.tcl -args targetcomplete0
