#!/bin/tcsh

rm *complete* blastout.txt 
rm -r templates
rm loop_candidates.txt
